/* =========================================================================
   Data — artworks, collections, testimonials, process
   Watercolour tints use a warm, low-chroma analogous range (hue 24–96)
   so the placeholder grid carries gentle rhythm without shouting.
   ========================================================================= */
(function () {

  // soft watercolour washes for placeholders — [hue, chroma, light]
  const COLLECTIONS = [
    { id: "culture",   no: "01", title: "Nepalese Culture",     count: 18, hue: 28,
      blurb: "Festivals, prayer flags and the quiet rituals of the courtyards of Kathmandu." },
    { id: "portrait",  no: "02", title: "Portraits",            count: 24, hue: 44,
      blurb: "Faces weathered by altitude and devotion — studies in patience and pigment." },
    { id: "himalaya",  no: "03", title: "Himalayan Landscapes", count: 21, hue: 220,
      blurb: "First light on snow, monsoon valleys, the long blue distance of the high passes." },
    { id: "wildlife",  no: "04", title: "Wildlife",             count: 16, hue: 96,
      blurb: "The tiger, the danphe, the river otter — caught in a single held breath of water." },
    { id: "lifestyle", no: "05", title: "Traditional Lifestyle",count: 19, hue: 64,
      blurb: "Tea fields, terraced farms and the slow choreography of mountain daily life." },
    { id: "sketches",  no: "06", title: "Watercolour Sketches", count: 32, hue: 36,
      blurb: "Loose, fast, unguarded — the notebook where every finished work begins." },
  ];

  function wash(hue, l) {
    // build a layered, paper-like wash background as a data string of CSS gradients
    return { hue: hue, l: l };
  }

  // Featured / gallery artworks
  const ARTWORKS = [
    { id: "a1", title: "Indra Jatra, Dusk",        year: "2024", medium: "Watercolour on cotton rag", size: "76 × 56 cm",
      coll: "culture",   hue: 26,  ratio: 0.78, feat: true,
      note: "Masked dancers under the last copper light of the festival square." },
    { id: "a2", title: "The Lama's Hands",          year: "2023", medium: "Watercolour & graphite",     size: "40 × 50 cm",
      coll: "portrait",  hue: 42,  ratio: 1.28, feat: true,
      note: "A study of stillness — beads, knuckles, ninety winters." },
    { id: "a3", title: "Machhapuchhre, First Light", year: "2024", medium: "Watercolour on cotton rag", size: "90 × 60 cm",
      coll: "himalaya",  hue: 218, ratio: 0.7, feat: true,
      note: "The fishtail summit emerging from the cold blue of dawn." },
    { id: "a4", title: "Bengal Tiger, Bardiya",     year: "2023", medium: "Watercolour on rag",         size: "70 × 50 cm",
      coll: "wildlife",  hue: 92,  ratio: 0.82, feat: true,
      note: "Wet-in-wet stripes dissolving into the tall grass." },
    { id: "a5", title: "Tea Pickers, Ilam",         year: "2022", medium: "Watercolour on cotton rag",  size: "64 × 48 cm",
      coll: "lifestyle", hue: 62,  ratio: 1.18, feat: false,
      note: "Bent backs and baskets across the green terraces." },
    { id: "a6", title: "Boudhanath in Rain",        year: "2024", medium: "Watercolour sketch",         size: "30 × 30 cm",
      coll: "sketches",  hue: 34,  ratio: 1, feat: false,
      note: "Fifteen minutes, one brush, the great stupa under monsoon." },
    { id: "a7", title: "Woman of Mustang",          year: "2023", medium: "Watercolour & graphite",     size: "42 × 56 cm",
      coll: "portrait",  hue: 38,  ratio: 0.75, feat: false,
      note: "Coral, turquoise and a gaze that has crossed the high desert." },
    { id: "a8", title: "Danphe in Snow",            year: "2024", medium: "Watercolour on rag",         size: "38 × 46 cm",
      coll: "wildlife",  hue: 200, ratio: 0.84, feat: false,
      note: "The Himalayan monal — iridescence built in transparent layers." },
    { id: "a9", title: "Prayer Flags, Langtang",    year: "2022", medium: "Watercolour on cotton rag",  size: "80 × 54 cm",
      coll: "culture",   hue: 30,  ratio: 0.74, feat: false,
      note: "Lungta scattering colour across a thin mountain wind." },
    { id: "a10", title: "Annapurna Sanctuary",      year: "2023", medium: "Watercolour on rag",         size: "100 × 56 cm",
      coll: "himalaya",  hue: 224, ratio: 0.56, feat: false,
      note: "A panorama held in one continuous wet wash." },
    { id: "a11", title: "Potter of Bhaktapur",      year: "2024", medium: "Watercolour sketch",         size: "32 × 40 cm",
      coll: "lifestyle", hue: 48,  ratio: 0.8, feat: false,
      note: "Clay, wheel, and hands that have never hurried." },
    { id: "a12", title: "River Otter, Karnali",     year: "2022", medium: "Watercolour sketch",         size: "28 × 28 cm",
      coll: "sketches",  hue: 70,  ratio: 1, feat: false,
      note: "A quick gesture — wet fur, wet paper, wet light." },
  ];

  const PROCESS = [
    { no: "01", title: "The Paper", hue: 40,
      text: "Every painting begins with cold-pressed cotton rag, torn by hand and stretched the night before. The tooth of the paper decides how the water will move." },
    { no: "02", title: "First Wash", hue: 28,
      text: "Working wet-into-wet, the largest shapes go down first — sky, distance, shadow — in a single uninterrupted breath before the paper dries." },
    { no: "03", title: "Building Light", hue: 52,
      text: "Layer over transparent layer, the light is never added — it is the paper, protected. Each glaze is a decision that cannot be taken back." },
    { no: "04", title: "The Detail", hue: 36,
      text: "Only at the end, with a near-dry brush, do the eyes, the stitch, the single blade of grass arrive. Restraint is the whole discipline." },
  ];

  const TESTIMONIALS = [
    { quote: "Kobit paints water with water. Standing before the Machhapuchhre piece, I felt the cold of that dawn on my own skin.",
      who: "Aruna Rana", role: "Curator, Kathmandu Contemporary" },
    { quote: "A self-taught mastery that institutions spend lifetimes chasing. The restraint is what undoes you — he knows exactly what to leave as paper.",
      who: "Daniel Hofmann", role: "Collector, Zürich" },
    { quote: "The portraits do not flatter; they remember. Each face carries the altitude it was painted at.",
      who: "Sushila Pradhan", role: "Editor, Himal Review" },
  ];

  window.GALLERY = { COLLECTIONS, ARTWORKS, PROCESS, TESTIMONIALS };
})();
